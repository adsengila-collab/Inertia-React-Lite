# WallpaperHub — Panduan Deploy di CyberPanel

## Struktur File

```
wallpaperhub/
  dist/
    index.mjs          ← Entry point server
    pino-*.mjs         ← Logger workers
    public/            ← Frontend (React build)
      index.html
      assets/
  data/
    keywords.txt       ← Database keyword (file teks)
  package.json
  .env.example
```

## Cara Deploy di CyberPanel

### 1. Upload & Extract
- Upload file `wallpaperhub.zip` ke server Anda
- Extract ke folder website, misal: `/home/domain.com/public_html/`

### 2. Setup Node.js App di CyberPanel
- Masuk CyberPanel → **Websites** → pilih domain Anda
- Klik **Create Node.js App**
- **Application Root**: `/home/domain.com/public_html/wallpaperhub`
- **Application URL**: `/` (atau subdomain)
- **Application Startup File**: `dist/index.mjs`
- **Node.js Version**: 18 atau lebih baru

### 3. Set Environment Variable
- Di CyberPanel Node.js App settings, tambahkan env var:
  ```
  PORT=3000
  NODE_ENV=production
  ```

### 4. Jalankan App
- Klik **Create** atau **Restart** di CyberPanel
- Pastikan port 3000 diarahkan ke domain Anda via reverse proxy

### 5. Verifikasi
- Buka domain Anda di browser
- API bisa ditest: `https://domain.com/api/keywords`

## Catatan Penting

- **keywords.txt**: File `data/keywords.txt` berisi semua keyword Anda. Pastikan folder `data/` bisa di-write oleh server (permission 755 atau 777)
- **Port**: Ubah PORT sesuai konfigurasi CyberPanel Anda
- **Tidak perlu npm install**: Semua dependensi sudah di-bundle dalam `dist/index.mjs`

## Menambah Keyword

Akses halaman admin di: `https://domain.com/admin/keywords`

## Sitemap

- Index: `https://domain.com/sitemap/index.xml`
- Submit ke Google Search Console untuk indexing
